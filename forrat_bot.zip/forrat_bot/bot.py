import asyncio
from aiogram import Bot, Dispatcher, types
from aiogram.filters import Command
from aiogram.types import Message

API_TOKEN = '8070576562:AAFxcq6FejTe6QCSfKNuzvSyovGv8rZLR5s'
bot = Bot(token=API_TOKEN)
dp = Dispatcher()

questions = [
    {"question": "Сколько будет 2 + 2?", "options": ["3", "4", "5"], "answer": "4"},
    {"question": "Сколько будет 5 * 3?", "options": ["15", "10", "20"], "answer": "15"},
    {"question": "Сколько будет 9 - 4?", "options": ["5", "6", "7"], "answer": "5"},
    {"question": "Сколько будет 8 / 2?", "options": ["4", "3", "5"], "answer": "4"},
    {"question": "Сколько будет 7 + 6?", "options": ["12", "13", "14"], "answer": "13"},
]

current_question_index = 0
correct_answers = 0

@dp.message(Command("start"))
async def send_welcome(message: Message):
    global current_question_index, correct_answers
    current_question_index = 0
    correct_answers = 0
    await ask_question(message.chat.id)

async def ask_question(chat_id):
    global current_question_index
    if current_question_index < len(questions):
        question = questions[current_question_index]
        await bot.send_message(chat_id, question["question"])
    else:
        await finish_quiz(chat_id)

@dp.message()
async def handle_answer(message: Message):
    global current_question_index, correct_answers
    if current_question_index < len(questions):
        question = questions[current_question_index]
        if message.text == question["answer"]:
            correct_answers += 1
            await message.reply("Правильно!")
        else:
            await message.reply("Неправильно. Правильный ответ: " + question["answer"])
        current_question_index += 1
        await ask_question(message.chat.id)
    else:
        await finish_quiz(message.chat.id)

async def finish_quiz(chat_id):
    global correct_answers
    await bot.send_message(chat_id, f"Викторина завершена! Вы ответили правильно на {correct_answers} из 5 вопросов. Хотите сыграть еще раз? Напишите /start.")

async def main():
    await dp.start_polling(bot)

if __name__ == '__main__':
    asyncio.run(main())